package com.example.KonectaAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KonectaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(KonectaApiApplication.class, args);
	}

}
